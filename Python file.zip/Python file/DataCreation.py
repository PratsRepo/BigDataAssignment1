import numpy as np
import pandas as pd
import time


# Do NOT change this
prng = np.random.RandomState(987654321)
df_users = pd.DataFrame(columns=["ID", "Surname", "Name", "Age", "Subscription Date"])
number = 100000
names = ["Hans", "Jordi", "Franz", "Timothy", "Agaba", "Ali", "Sarah", "Josie", "Robert",
         "Francine", "Anna", "Zoe", "Simon", "Thomas", "Andreas", "Alok", "Lee", "Jean-Luc"]
surnames = ["Mueller", "Meier", "Smith", "Gwahsi", "Thronton", "Wellington", "Stephenson",
            "Pomme", "Di Lillo", "Bond", "Kirk", "Picard", "Roth", "Beierlorzer"]


def normalize_age(age, lower=16.0, upper=99.0):
    if age < lower:
        return lower
    elif age > upper:
        return upper
    return age


start = time.time()
userid = list(range(1, number+1))
surname = prng.choice(surnames, number)
name = prng.choice(names, number)
age = prng.normal(35., 10., number)
# Normalize age to between 16 and 99:
# ok, but slow
na = np.vectorize(normalize_age)(age)
sub_date = 1588150183 + prng.normal(10000., 5000., number)
df_users = pd.DataFrame(np.array([userid, surname, name, na, sub_date]).T.tolist())
df_users.columns = ['ID', 'Surname', 'Name', 'Age', 'Subscription_Date']
print(df_users.info())
# You may import this file to R if you wish to work with that language.
df_users.to_csv("user_table.csv")

# Next, we will create a set of posts for each user.
# To this end, we will synthesize text from the "Lorem_ipsum.txt" file.

with open("Lorem_ipsum.txt") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
content = [x.strip() for x in content]

post_number = 1000000
post_id = list(range(1, post_number+1))
snippet_index = list(range(len(content)))
posts = prng.choice(snippet_index, post_number, replace=True)
posts_uids = prng.randint(1, number, post_number)
posts_date = 1588150183 + 5000000 + prng.normal(100000., 50000., post_number)
posts_content = [content[i] for i in posts]
df_posts = pd.DataFrame(np.array([post_id, posts_uids, posts_content, posts_date]).T.tolist())
df_posts.columns = ['PostID', 'UserID', 'Content', 'Timestamp']
df_posts.info()
df_posts.to_csv("postings_table.csv")
end = time.time()
print("Data Generation took ", (end - start), " seconds.")
# This is the end of the data generation.
print(df_users.head())
print("User Table")
print(df_posts.head())
print("Posts Table")
